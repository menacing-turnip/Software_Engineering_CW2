class Admin extends User
{
    constructor(name, accountNumber, username, password, moneyAccount)
    {
        super(name, accountNumber, username, password, moneyAccount);
    }

    viewParkingMap(parkingMap)
    {

    }

    addParkingLot(parkingLot)
    {

    }

    removeParkingLot(parkingLot)
    {

    }

    blockParkingSpace(parkingSpace)
    {

    }

    reserveParkingSpace(parkingSpace)
    {

    }

    manageParkingRequests(parkingSpace)
    {

    }

    assignParkingLocation(parkingSpace)
    {

    }

    changeAssignedLocation(parkingSpace)
    {

    }

    removeUser(user)
    {

    }

    banUser(user)
    {

    }
}