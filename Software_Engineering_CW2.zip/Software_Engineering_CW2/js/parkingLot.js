class ParkingLot
{
    // Private instance attributes for abstraction
    #parkingSpaces;
    #parkingSpaceNo;
    #maxParkingSpaces;
    #keyBuilding;

    constructor(maxParkingSpaces)
    {
        this.#parkingSpaces = [];
        this.#maxParkingSpaces = maxParkingSpaces;
        //this.#keyBuilding = keyBuilding;
        //this.#parkingSpaceNo = this.#parkingSpaces.length;
        this.#parkingSpaceNo = 0;
    }

    // Accessor methods
    get parkingSpaces()
    {
        return this.#parkingSpaces;
    }

    set parkingSpaces(parkingSpaces)
    {
        this.#parkingSpaces = parkingSpaces;
    }

    get maxParkingSpaces()
    {
        return this.#maxParkingSpaces;
    }

    set maxParkingSpaces(maxParkingSpaces)
    {
        this.#maxParkingSpaces = maxParkingSpaces;
    }

    get parkingSpaceNo()
    {
        return this.#parkingSpaceNo;
    }
    
    get keyBuilding()
    {
        return this.#keyBuilding;
    }

    set keyBuilding(keyBuilding)
    {
        this.#keyBuilding = keyBuilding;
    }

    addParkingSpace(location)
    {
        if (this.#parkingSpaceNo < this.#maxParkingSpaces)
        {
            const parkSpaceId = this.#parkingSpaceNo;
            this.#parkingSpaceNo++;
            console.log("Parking Space Number: "+this.#parkingSpaceNo);
            const newParkSpace = new ParkingSpace(parkSpaceId, location);
            console.log(newParkSpace.toString());
            this.#parkingSpaces.push(newParkSpace);
        }
    }
}
