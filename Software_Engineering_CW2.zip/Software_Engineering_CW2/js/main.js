console.log(5 / 3);

const parkingLot = new ParkingLot(23);

let parkSpaceRow = 0, parkSpaceColumn = 0;

for (let i = 0; i < parkingLot.maxParkingSpaces; i++)
{
    let xcoord = 0, ycoord = 0;

    if (i != 0)
    {
        if (i % 5 == 0)
        {
            parkSpaceRow = 0;
            parkSpaceColumn++;
        }
        else
        {
            parkSpaceRow++;
        }
    }

    xcoord = 50 * parkSpaceColumn;
    ycoord = 20 * parkSpaceRow;

    const location = new Location(xcoord, ycoord);

    parkingLot.addParkingSpace(location);
    console.log(parkingLot.parkingSpaces[i].toString());
}

const parkingLotMap = new ParkingMap(parkingLot);

document.body.append(parkingLotMap.createParkingLotMap());