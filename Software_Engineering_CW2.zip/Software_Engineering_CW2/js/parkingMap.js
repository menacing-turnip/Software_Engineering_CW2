class ParkingMap
{
    #parkingLot;

    constructor(parkingLot)
    {
        this.#parkingLot = parkingLot;
    }

    // Accessor methods
    get parkingLot()
    {
        return this.#parkingLot;
    }

    set parkingLot(parkingLot)
    {
        this.#parkingLot = parkingLot;
    }

    createParkingLotMap()
    {
        const   parkingLotDiv = document.createElement("div"),
                parkingSpaceNo = this.#parkingLot.parkingSpaceNo;
                
        let maxColumns = Math.trunc(parkingSpaceNo / 5);

        if (parkingSpaceNo % 5 != 0)
        {
            maxColumns++;
        }

        for (let i = 0; i < maxColumns; i++)
        {
            const parkingLotColumnDiv = document.createElement("div");
            for (let j = 0; j < 5; j++)
            {
                if (parkingSpaceNo - ((i * 5) + j + 1) >= 0)
                {
                    const parkingSpaceDiv = document.createElement("div");
                    parkingSpaceDiv.className = "parking-space-div";
                    parkingSpaceDiv.innerHTML = this.#parkingLot.parkingSpaces[(i * 5) + j].id;
                    parkingLotColumnDiv.className = "parking-space-column-div";
                    parkingLotColumnDiv.append(parkingSpaceDiv);
                }
            }
            parkingLotDiv.id = "parking-lot-div";
            parkingLotDiv.append(parkingLotColumnDiv);
        }
        return parkingLotDiv;
    }

    findPath(targetLocation){ // find the route to the supplied location
        i = 0;
        spacesPerRow = 5;
        while (((i * spacesPerRow * 2) + spacesPerRow) <= targetLocation){
            i++
        }
        width = i;

        height = ((width * spacesPerRow) + 5) - targetLocation;

        if (height < spacesPerRow){
            height = (spacesPerRow * 2) - height
            onTheRight = false;
        }
        else
            onTheRight = true;

        
    }
}
